/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Beans;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Sebastián
 */
@Entity
@Table(name = "cita")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cita.findAll", query = "SELECT c FROM Cita c")
    , @NamedQuery(name = "Cita.findByNCita", query = "SELECT c FROM Cita c WHERE c.nCita = :nCita")
    , @NamedQuery(name = "Cita.findByFecha", query = "SELECT c FROM Cita c WHERE c.fecha = :fecha")})
public class Cita implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "NCita")
    private Integer nCita;
    @Basic(optional = false)
    @Column(name = "Fecha")
    @Temporal(TemporalType.TIMESTAMP)
    private Date fecha;
    @Lob
    @Column(name = "Observaciones")
    private String observaciones;
    @JoinColumn(name = "Doctor", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Doctor doctor;
    @JoinColumn(name = "Paciente", referencedColumnName = "Id")
    @ManyToOne(optional = false)
    private Persona paciente;

    public Cita() {
    }

    public Cita(Integer nCita) {
        this.nCita = nCita;
    }

    public Cita(Integer nCita, Date fecha) {
        this.nCita = nCita;
        this.fecha = fecha;
    }

    public Integer getNCita() {
        return nCita;
    }

    public void setNCita(Integer nCita) {
        this.nCita = nCita;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public String getPaciente() {
        return paciente.getId();
    }

    public void setPaciente(Persona paciente) {
        this.paciente = paciente;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (nCita != null ? nCita.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cita)) {
            return false;
        }
        Cita other = (Cita) object;
        if ((this.nCita == null && other.nCita != null) || (this.nCita != null && !this.nCita.equals(other.nCita))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Beans.Cita[ nCita=" + nCita + " ]";
    }
    
}
