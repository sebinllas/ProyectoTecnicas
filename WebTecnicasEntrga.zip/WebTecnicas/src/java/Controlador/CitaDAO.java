/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Beans.Cita;
import Beans.Persona;
import com.mysql.jdbc.ResultSetImpl;
import java.sql.Connection;
import java.sql.Date;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sebastián
 */
public class CitaDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    Conexion conexion = new Conexion();

    public void agregar(Cita c) {

        try {

            System.out.println("Inicio agregar cita");
            conn = Conexion.getConexion();
            System.out.println("getConexion Done");
            String registroCita = "insert into cita (Doctor, Fecha, Paciente, Observaciones) values (?,?,?,?)";
            System.out.println("registro cita Assignment Done " + registroCita);
            ps = conn.prepareStatement(registroCita);
            System.out.println("prepareStatement Done");
            ps.setString(1, c.getDoctor().getNombre());
            java.sql.Date sqlDate = new java.sql.Date(c.getFecha().getTime());
            sqlDate.setTime(c.getFecha().getTime());

            ps.setString(3, c.getPaciente());
            ps.setString(4, c.getObservaciones());
            System.out.println("SetString Done" + ps.toString());
            ps.setDate(2, sqlDate);
            ps.executeUpdate();
            System.out.println("executeUpdate Done");

        } catch (SQLException e) {
            System.out.println("Error en CitaDAO ^ " + e);
            e.printStackTrace();
        } finally {

        }
    }
}
