/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador.Servlets;

import Beans.*;
import Controlador.CitaDAO;
import Controlador.Consultas;
import Controlador.PersonaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/**
 *
 * @author Sebastián
 */
public class RegistroCita extends HttpServlet {

    PersonaDAO per = new PersonaDAO();
    Persona person = new Persona();
    Cita cita = new Cita();
    CitaDAO cd = new CitaDAO();
    Doctor doc = new Doctor();

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        /*        */
        //System.out.println(person.toString() );
        //JOptionPane.showMessageDialog(null, "la fecha elegida es: "+ cita.getFecha().toString()+ "nombre "+person.getNombre()+" email "+person.getEmail());
        //JOptionPane.showMessageDialog(null,nombre + Id + Telefono + observaciones + Emial + IdDoctor);

        /*        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegistroCita</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegistroCita at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            }*/
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    /*    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    RequestDispatcher view = request.getRequestDispatcher("registro.jsp");
    view.forward(request, response);
    }*/

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response){

        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm");
            SimpleDateFormat dateFormat1 = new SimpleDateFormat("hh:mm");
            String nombre = request.getParameter("Name");
            String Emial = request.getParameter("Email");
            String Telefono = request.getParameter("Phone");
            String Id = request.getParameter("Id");
            String Date = request.getParameter("Date") + " " + request.getParameter("Hora");  
            String NameDoctor = request.getParameter("doctor");      
            String observaciones = request.getParameter("Observaciones");
            Date Fecha = dateFormat.parse(Date);
           
            doc.setNombre(NameDoctor);
            person.setNombre(nombre);
            System.out.println("Nombre " + person.getNombre());
            person.setId(Id);
            System.out.println("ID " + person.getId());
            person.setEmail(Emial);
            System.out.println("Email " + person.getEmail());
            person.setTelefono(Telefono);
            System.out.println("tel " + person.getTeléfono());
            cita.setPaciente(person);
            cita.setFecha(Fecha);
            System.out.println("Fecha " + cita.getFecha());
            cita.setObservaciones(observaciones);
            System.out.println("Obs " + cita.getObservaciones());
            cita.setDoctor(doc); 
            per.agregar(person);
            cd.agregar(cita);
            System.out.println("agregado correcta/e");

            
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            request.setAttribute("mensaje", "Cita agregada satisfactoriamente");
            view.forward(request, response);

        } catch (ParseException |ServletException| IOException ex) {
            ex.getStackTrace();
            System.out.println("Error:_______" + ex);
        }
    }

}
