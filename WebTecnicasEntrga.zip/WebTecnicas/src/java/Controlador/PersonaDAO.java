/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Beans.Persona;
import com.mysql.jdbc.ResultSetImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sebastián
 */
public class PersonaDAO {

    PreparedStatement ps = null;
    ResultSetImpl rs = null;
    Connection conn = null;
    Conexion conexion = new Conexion();

    public void agregar(Persona p) {

        try {

            System.out.println("Inicio agragr persona");
            conn = conexion.getConexion();
            System.out.println("getConexion Done");
            String registroPersona = "insert into persona (Nombre, Id, Telefono, Email) values (?,?,?,?)";
            System.out.println("registroPersona Assignment Done " + registroPersona);
            ps = conn.prepareStatement(registroPersona);
            System.out.println("prepareStatement Done");
            ps.setString(1, p.getNombre());
            ps.setString(2, p.getId());
            ps.setString(3, p.getTeléfono());
            ps.setString(4, p.getEmail());
            System.out.println("SetString Done" + ps.toString());
            ps.executeUpdate();
            System.out.println("executeUpdate Done");
            System.out.println("se cerró la conexión");

        } catch (SQLException e) {
            System.out.println("Error en PersonaDAO ^ " + e);
            e.printStackTrace();
        } finally {

        }
    }
}
