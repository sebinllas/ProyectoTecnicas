/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import Beans.Opinion;
import Beans.pqrsp;
import com.mysql.jdbc.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Sebastián
 */
public class pqrspDAO {
    PreparedStatement pst;
    ResultSet rs = null;
    Connection conn = null;
    Conexion conexion = new Conexion();

    public void agregar(pqrsp p) {
        try {
            conn = (Connection) conexion.getConexion();
            String registroCita = "insert into pqrsp(Nombre, Email, Mensaje) values (?,?,?,?)";
            pst = conn.prepareStatement(registroCita);
            pst.setString(1, p.getNombre());
            pst.setString(2, p.getEmail());
            pst.setString(3, p.getMensaje());

            pst.executeUpdate();
            
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                /* ignored */ }
        }
    }
}
