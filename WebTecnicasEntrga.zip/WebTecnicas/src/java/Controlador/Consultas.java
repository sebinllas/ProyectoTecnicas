/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Sebastián
 */
public class Consultas extends Conexion {
SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");


    public boolean autenticar(Date fecha, String IdDoctor) throws SQLException {
        PreparedStatement pst = null;
        ResultSet rs = null;
        
        try {
            String Consulta = "select * from cita where Fecha = ? and Doctor = ? ";

            pst.getConnection().prepareStatement(Consulta);
            pst.setString(1, dateFormat.format(fecha));
            pst.setString(2, IdDoctor);
            rs = pst.executeQuery();
            if (rs.absolute(1)) {
                return true;
            }
        } catch (Exception ex) {
            System.out.println("ERROR" + ex);
        } finally {
            if (getConexion() != null) {
                getConexion().close();
            }
            if (pst != null) {
                pst.close();
            }
            if (rs != null) {
                rs.close();
            }
        }
        return false;
    }

    /*    public boolean registrarCita(String Nombre, String IdPersona, String Telefono, String Email, String IdDoctor, Date Fecha, String Observaciones) {
    PreparedStatement pst = null;
    try{
    
    String registroPersona="insert into persona (Nombre, Id, Teléfono, Email) values (?,?,?,?)";
    //String registroPersona="insert into persona (Nombre, Id, Teléfono, Email) values ("+Nombre+","+IdPersona+","+Telefono+","+Email+")";
    pst=getConexion().prepareStatement(registroPersona);
    pst.setString(1,Nombre);
    pst.setString(2,IdPersona);
    pst.setString(3,Telefono);
    pst.setString(4,Email);
    
    String registroCita="insert into cita(Doctor, Fecha, Paciente, Observaciones) values (?,?,?,?)";
    pst=getConexion().prepareStatement(registroCita);
    pst.setString(1, IdDoctor);
    pst.setDate(2, (java.sql.Date) Fecha);
    pst.setString(3, IdPersona);
    pst.setString(4, Observaciones);
    
    if (pst.executeUpdate()>=1){
        return true;
    }
}catch(SQLException ex){
System.out.println(ex);
}finally{
if(getConexion()!=null)try {
getConexion().close();
if(pst!=null)pst.close();
} catch (SQLException ex) {
System.out.println(ex);
}

}
return false;
}*/
}
