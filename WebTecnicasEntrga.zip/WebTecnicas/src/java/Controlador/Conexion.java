/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Sebastián
 */
public class Conexion {

    private static Connection connec;


    private String USERNAME = "root";
    private String PASSWORD = "";
    private String HOST = "localhost";
    private String PORT = "3306";
    private String DATABASE = "proyecto";
    private String CLASSNAME = "com.mysql.jdbc.Driver";
    private String URL = "jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE+"?zeroDateTimeBehavior=convertToNull";

    public Conexion() {

        try {
            Class.forName(CLASSNAME);
            connec = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Conexión Exitosa");
        } catch (SQLException | ClassNotFoundException e) {
            System.out.println("Error en getConexion() " + e);
            e.printStackTrace();
        }
    }
    public static Connection getConexion() {
        return connec;
    }


}
